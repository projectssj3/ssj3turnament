const password="SSJ3ADMIN";
let input=prompt("Mot de passe admin :");
if(input===password){
    document.getElementById("content").innerHTML="<p>Bienvenue admin !</p><p>Gestion des tournois et matchs prête à être ajoutée.</p>";
}else{
    alert("Accès refusé");
    window.location.href="../index.html";
}