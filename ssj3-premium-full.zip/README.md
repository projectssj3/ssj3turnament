# SSJ3 Premium - Full Pack

Pack complet avec tournois, live Discord, inscriptions, classement et design premium.

## Fonctionnalités
- Admin sécurisé
- Inscription des joueurs
- Classement automatique
- Tournois et brackets dynamiques
- Match system + historique
- Live streaming (Discord)
- Design complet
- Prêt à déployer sur GitHub Pages

## Installation
1. Clonez le repo
2. Ouvrez `index.html`
3. Admin : `/admin/index.html` (mot de passe SSJ3ADMIN)
4. Configurez `json/` selon vos besoins
