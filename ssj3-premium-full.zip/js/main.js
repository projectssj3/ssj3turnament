function inscription(){
    let name = prompt('Entrez votre pseudo :');
    if(!name) return alert('Nom invalide');
    fetch('json/users.json')
    .then(res => res.json())
    .then(users => {
        let id = users.length + 1;
        users.push({id: id, name: name});
        fetch('json/users.json', {
            method:'PUT',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify(users)
        }).then(()=>alert('Inscription réussie !')).catch(()=>alert('Impossible d'enregistrer.'));
    });
    console.log('Inscription simulée (GitHub Pages ne peut pas modifier JSON directement).');
}